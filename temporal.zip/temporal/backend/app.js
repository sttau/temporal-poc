const express = require('express');
const { json, urlencoded } = require('body-parser');
const cors = require('cors');
const routes = require('./src/routes');
const mongoose = require('mongoose');
require('dotenv').config();

mongoose.connect(process.env.DB_MONGO_URL);
const database = mongoose.connection;

database.once('connected', () => {
  console.log('Database Connected');
});

const app = express();

app.use(json());
// parse requests of content-type - application/json
app.use(express.json());
// parse requests of content-type - application/x-www-form-urlencoded
app.use(express.urlencoded({ extended: true }));
app.use(cors());

app.use(json());

app.use(
  urlencoded({
    extended: true,
  })
);

app.use(routes);

module.exports = app;
