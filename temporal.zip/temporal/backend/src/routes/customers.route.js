const express = require('express');
const router = express.Router();
const customerController = require('../controllers/customers.controller');

router.get('/', customerController.get);
router.post('/store/transaction', customerController.customerTransaction);
router.get('/transactions/:id', customerController.getTransactions);
router.get('/transactions/process/:id', customerController.processTransaction);

module.exports = router;
