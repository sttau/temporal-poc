const express = require('express');
const router = express.Router();
const transactionController = require('../controllers/transactions.controller');

router.get('/', transactionController.get);
router.get('/single', transactionController.getSingle);
router.get('/repairs', transactionController.getRepairs);
router.post('/repair/:id', transactionController.repairTransaction);

module.exports = router;
