const express = require('express');
const router = express.Router();

const serviceRouter = require('./services.route');
const transactionRouter = require('./transactions.route');
const customerRouter = require('./customers.route');

router.use('/services', serviceRouter);
router.use('/transactions', transactionRouter);
router.use('/customers', customerRouter);

module.exports = router;
