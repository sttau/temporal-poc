const express = require('express');
const router = express.Router();
const serviceController = require('../controllers/services.controller');

router.get('/', serviceController.get);
router.post('/process', serviceController.process);
router.post('/:id', serviceController.update);

module.exports = router;
