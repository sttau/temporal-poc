const mongoose = require('mongoose');
require('dotenv').config();

mongoose.connect(process.env.DB_MONGO_URL);

const { show } = require('../services/services.service');
const {
  create,
  createSingle,
  update,
  updateSingle,
  updateParent,
} = require('../services/transactions.service');
const { literal } = require('sequelize');
const joi = require('joi');
const JoiDate = require('@hapi/joi-date');

const Joi = joi.extend(JoiDate);

exports.fileManagementService = async (data) => {
  return serviceProcess('File Management');
};

exports.databaseService = async (uuid, { data, parent }) => {
  return new Promise((resolve, reject) => {
    serviceProcess('Database')
      .then(async () => {
        // console.log(uuid, data);
        // return resolve(123);
        try {
          const res = await create(uuid, data, parent);
          return resolve(res);
        } catch (err) {
          return reject(err);
        }
      })
      .catch((err) => {
        return reject(err);
      });
  });
};

exports.databaseSingleService = async (uuid, { data }) => {
  return new Promise((resolve, reject) => {
    serviceProcess('Database')
      .then(async () => {
        try {
          const res = await createSingle(uuid, data);
          return resolve(res);
        } catch (err) {
          return reject(err);
        }
      })
      .catch((err) => {
        return reject(err);
      });
  });
};

exports.fxService = async () => {
  return serviceProcess('FX Service');
};

exports.qualificationService = async () => {
  return serviceProcess('Qualification');
};

exports.balanceAndLimitsService = async () => {
  return serviceProcess('Balance and Limits');
};

exports.entitlementsService = async () => {
  return serviceProcess('Entitlements');
};

exports.paymentVerificationService = async () => {
  return serviceProcess('Payment Verification');
};

exports.securityScanService = async () => {
  return serviceProcess('Security scan');
};

exports.paymentValidationService = async (uuid, { data }) => {
  return new Promise((resolve, reject) => {
    serviceProcess('Payment Validation').then(async () => {
      const schema = Joi.object({
        'Order Party Account': Joi.string().required().max(35),
        'Order Party Currency': Joi.string().required().max(3),
        'Charges Account': Joi.string().required().max(35),
        'Charges Account Currency': Joi.string().required().max(3),
        'Account Currency': Joi.string().required().max(3),
        'Transaction Amount': Joi.number().required().precision(2),
        'Scheduled date': Joi.date().format('DDMMYYYY').required(),
        'Transaction currency': Joi.string().required().max(3),
        'Counter Party Account': Joi.string().required().max(35),
        'Counter Account Type': Joi.string().required().max(2),
        'Counter Bank Name': Joi.string().required().max(35),
        'Counter Account Currency': Joi.string().required().max(3),
        'Product code': Joi.string().required().max(3),
        'Value date / Execution date': Joi.date().format('DDMMYYYY').required(),
        'Transaction Mode': Joi.string().required().max(3),
      }).required();

      const { error } = await schema.validate(data, {
        abortEarly: false,
      });

      if (error) {
        if (error.details.length > 7) {
          return resolve({
            success: false,
            message: `Validation Error ${error}`,
          });
        } else {
          return resolve({
            success: false,
            canRepair: true,
            errors: error.details,
            message: `Validation Error ${error}`,
          });
        }
      } else {
        return resolve({
          success: true,
          message: 'Passed Validation.',
        });
      }
    });
  });
};

exports.paymentObjetStoreService = async (uuid, { parent }) => {
  return new Promise((resolve, reject) => {
    serviceProcess('Payment Object Store')
      .then(async () => {
        try {
          const res = await update(uuid, {
            status: 'completed',
          });

          await updateParent(parent._id, {
            $inc: { processed: 1 },
          });

          return resolve(res);
        } catch (err) {
          return reject(err);
        }
      })
      .catch((err) => {
        return reject(err);
      });
  });
};

exports.paymentObjetRepairStoreService = async (uuid, { parent }) => {
  return new Promise((resolve, reject) => {
    serviceProcess('Payment Object Store')
      .then(async () => {
        try {
          const res = await update(uuid, {
            status: 'completed',
          });

          await updateParent(parent._id, {
            $inc: { processed: 1, repairing: -1 },
          });

          return resolve(res);
        } catch (err) {
          return reject(err);
        }
      })
      .catch((err) => {
        return reject(err);
      });
  });
};

exports.paymentObjetSingleStoreService = async (uuid) => {
  return new Promise((resolve, reject) => {
    serviceProcess('Payment Object Store')
      .then(async () => {
        try {
          const res = await updateSingle(uuid, {
            status: 'completed',
          });

          return resolve(res);
        } catch (err) {
          return reject(err);
        }
      })
      .catch((err) => {
        return reject(err);
      });
  });
};

exports.paymentObjectFailedService = async (uuid, { parent, message }) => {
  return new Promise((resolve, reject) => {
    serviceProcess('Payment Object Store')
      .then(async () => {
        try {
          const res = await update(uuid, {
            status: 'failed',
            message: message,
          });

          await updateParent(parent._id, {
            $inc: { failed: 1 },
          });
          return resolve(res);
        } catch (err) {
          return reject(err);
        }
      })
      .catch((err) => {
        return reject(err);
      });
  });
};

exports.paymentObjectRepairService = async (
  uuid,
  { parent, message, errors }
) => {
  return new Promise((resolve, reject) => {
    serviceProcess('Payment Object Store')
      .then(async () => {
        try {
          const res = await update(uuid, {
            status: 'waiting repair',
            message: message,
            validation_err: errors,
          });

          await updateParent(parent._id, {
            $inc: { repairing: 1 },
          });
          return resolve(res);
        } catch (err) {
          return reject(err);
        }
      })
      .catch((err) => {
        return reject(err);
      });
  });
};

function serviceProcess(name) {
  return new Promise((resolve, reject) => {
    show(name)
      .then((data) => {
        if (data.status === 'stopped') {
          return reject('Service stopped.');
        } else if (data.performance !== 'normal') {
          setTimeout(() => {
            return resolve(`Processed ${name}`);
          }, 10000);
        } else {
          return resolve(`Processed ${name}`);
        }
      })
      .catch(() => {
        return reject(`Service ${name} error.`);
      });
  });
}
