const { proxyActivities, CancellationScope } = require('@temporalio/workflow');

const {
  databaseService,
  databaseSingleService,
  paymentValidationService,
  fxService,
  entitlementsService,
  qualificationService,
  balanceAndLimitsService,
  paymentVerificationService,
  securityScanService,
  paymentObjetStoreService,
  paymentObjetRepairStoreService,
  paymentObjetSingleStoreService,
  paymentObjectFailedService,
  paymentObjectRepairService,
  fileManagementService,
} = proxyActivities({
  startToCloseTimeout: '1 minute',
});

/** A workflow that simply calls an activity */
exports.processTransaction = async function processTransaction(
  workflowId,
  data
) {
  await entitlementsService();
  await fileManagementService();
  await fxService();
  await securityScanService();

  await paymentValidationService(workflowId, data).then(async (res) => {
    if (!res.success) {
      await databaseService(workflowId, data);

      if (res.canRepair) {
        await paymentObjectRepairService(workflowId, {
          ...data,
          ...{ message: res.message, errors: res.errors },
        });
      } else {
        await paymentObjectFailedService(workflowId, {
          ...data,
          ...{ message: res.message },
        });
      }

      CancellationScope.current().cancel();
    }
  });

  await paymentVerificationService();
  await databaseService(workflowId, data);

  return await paymentObjetStoreService(workflowId, data);
};

/** A workflow that simply calls an activity */
exports.repairTransaction = async function repairTransaction(
  workflowId,
  data,
  parent
) {
  let dataNew = { data: data, parent: parent };
  await entitlementsService();
  await fileManagementService();
  await fxService();
  await securityScanService();

  await paymentValidationService(workflowId, dataNew).then(async (res) => {
    if (!res.success) {
      if (res.canRepair) {
        await paymentObjectRepairService(workflowId, {
          ...dataNew,
          ...{ message: res.message, errors: res.errors },
        });
      } else {
        await paymentObjectFailedService(workflowId, {
          ...dataNew,
          ...{ message: res.message },
        });
      }

      CancellationScope.current().cancel();
    }
  });

  await paymentVerificationService();

  return await paymentObjetRepairStoreService(workflowId, dataNew);
};

/** A workflow that simply calls an activity */
exports.processSingleTransaction = async function processSingleTransaction(
  workflowId,
  data
) {
  await databaseSingleService(workflowId, data);
  await entitlementsService();
  await qualificationService();
  await balanceAndLimitsService();

  await paymentVerificationService();
  await balanceAndLimitsService();

  return await paymentObjetSingleStoreService(workflowId, data);
};
