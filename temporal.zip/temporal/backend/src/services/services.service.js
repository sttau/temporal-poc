const Services = require('../mongo_models/services');
const mongoose = require('mongoose');

async function get() {
  const result = await Services.find();

  if (result) {
    return result;
  }

  return { error: 'Error while getting user list.' };
}

async function update(id, payload) {
  const result = await Services.findByIdAndUpdate(id, payload);

  if (result) {
    return result;
  }

  return { error: 'Error while getting user list.' };
}

async function show(name) {
  const result = await Services.findOne({
    name: name,
  });

  if (result) {
    return result;
  }

  return { error: 'Error while getting user list.' };
}

module.exports = {
  get,
  update,
  show,
};
