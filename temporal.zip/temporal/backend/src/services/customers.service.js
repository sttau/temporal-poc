const Customers = require('../mongo_models/customers');
const CustomerTransactions = require('../mongo_models/customer_transactions');
const Transaction = require('../mongo_models/transaction');

async function get() {
  const result = await Customers.find();

  if (result) {
    return result;
  }

  return { error: 'Error while getting user list.' };
}

async function getTransactions(id) {
  const result = await CustomerTransactions.find({
    customer_id: id,
    processed: false,
  });

  if (result) {
    return result;
  }

  return { error: 'Error while getting user list.' };
}

async function showTransaction(id) {
  const result = await CustomerTransactions.findById(id);

  const customer = await Customers.findById(result.customer_id);

  if (result) {
    return { customer: customer, transaction: result };
  }

  return { error: 'Error while getting user list.' };
}

async function storeTransaction(payload) {
  const data = new CustomerTransactions({
    ...payload,
    ...{ processed: false },
  });

  const result = await data.save();

  if (result) {
    return result;
  }

  return { error: 'Error while creating transaction' };
}

async function updateProcessed(id) {
  const result = await CustomerTransactions.findByIdAndUpdate(id, {
    processed: true,
  });

  if (result) {
    return result;
  }

  return { error: 'Error while updating transaction.' };
}

module.exports = {
  get,
  storeTransaction,
  getTransactions,
  showTransaction,
  updateProcessed,
};
