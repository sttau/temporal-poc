const Transaction = require('../mongo_models/transaction');
const SingleTransaction = require('../mongo_models/single_transactions');

async function get() {
  const result = await Transaction.find();

  if (result) {
    return result;
  }

  return { error: 'Error while getting user list.' };
}

async function getSingle() {
  const result = await SingleTransaction.find();

  if (result) {
    return result;
  }

  return { error: 'Error while getting user list.' };
}

async function getRepairs() {
  const result = await Transaction.find({
    status: 'waiting repair',
  });

  if (result) {
    return result;
  }

  return { error: 'Error while getting user list.' };
}

async function create(uuid, payload, parentTransaction = null) {
  const data = new Transaction({
    details: payload,
    uuid: uuid,
    status: 'pending',
    parent_id: parentTransaction._id,
  });

  const result = await data.save();

  if (result) {
    return result;
  }

  return { error: 'Error while creating transaction' };
}

async function createSingle(uuid, payload) {
  const data = new SingleTransaction({
    details: payload,
    uuid: uuid,
    status: 'pending',
  });

  const result = await data.save();

  if (result) {
    return result;
  }

  return { error: 'Error while creating transaction' };
}

async function createParent(payload) {
  const data = new Transaction({
    ...payload,
    processed: 0,
    failed: 0,
  });

  const result = await data.save();

  if (result) {
    return result;
  }

  return { error: 'Error while creating transaction' };
}

async function update(id, payload) {
  const result = await Transaction.update(
    {
      uuid: id,
    },
    { $set: payload }
  );

  if (result) {
    return result;
  }

  return { error: 'Error while updating transaction.' };
}

async function updateSingle(id, payload) {
  const result = await SingleTransaction.update(
    {
      uuid: id,
    },
    { $set: payload }
  );

  if (result) {
    return result;
  }

  return { error: 'Error while updating transaction.' };
}

async function updateParent(id, payload) {
  const result = await Transaction.findByIdAndUpdate(id, payload);

  if (result) {
    return result;
  }

  return { error: 'Error while updating transaction.' };
}

async function repairTransaction(id, payload) {
  const result = await Transaction.findByIdAndUpdate(id, {
    $set: {
      details: payload,
      status: 'pending',
    },
  });

  if (result) {
    return result;
  }

  return { error: 'Error while updating transaction.' };
}

async function show(id) {
  const result = await Transaction.findById(id);

  if (result) {
    return result;
  }

  return { error: 'Error while getting user list.' };
}

module.exports = {
  get,
  getSingle,
  getRepairs,
  create,
  createParent,
  createSingle,
  update,
  updateParent,
  updateSingle,
  repairTransaction,
  show,
};
