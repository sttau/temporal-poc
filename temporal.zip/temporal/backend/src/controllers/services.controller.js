const servicesService = require('../services/services.service');
const transactionService = require('../services/transactions.service');
const reader = require('xlsx');
const multiparty = require('multiparty');
const Joi = require('joi');
const { transactionQueue } = require('../queues/transactionQueue');
const { toString } = require('../utils/helpers');

async function get(req, res, next) {
  try {
    res.json(await servicesService.get());
  } catch (err) {
    console.error(`Error while getting`, err.message);
    next(err);
  }
}

async function update(req, res, next) {
  try {
    res.json(await servicesService.update(req.params.id, req.body));
  } catch (err) {
    console.error(`Error while getting`, err.message);
    next(err);
  }
}

const columnsValidation = [
  'Order Party Account',
  'Order Party Currency',
  'Charges Account',
  'Charges Account Currency',
  'Account Currency',
  'Transaction Amount',
  'Scheduled date',
  'Transaction currency',
  'Counter Party Account',
  'Counter Account Type',
  'Counter Bank Name',
  'Counter Account Currency',
  'Product code',
  'Value date / Execution date',
  'Transaction Mode',
];

async function process(req, res) {
  const form = new multiparty.Form();
  form.parse(req, async function (err, fields, files) {
    const file = files.file[0];

    const workbook = reader.readFile(file.path);
    const sheetName = workbook.SheetNames[0];

    const rows = reader.utils.sheet_to_json(workbook.Sheets[sheetName], {
      header: 1,
      blankrows: false,
    });

    const schema = Joi.object({
      columns: Joi.array().items(...columnsValidation),
    }).required();

    const { error } = await schema.validate({ columns: rows[0] });
    if (error) return res.status(400).json({ error: error.details[0] });

    const parentTransaction = await transactionService.createParent({
      total: rows.length - 1,
      details: {
        name: `${file.originalFilename}-${new Date().getTime()}`,
      },
    });

    reader.utils
      .sheet_to_json(workbook.Sheets[sheetName])
      .forEach((transaction) => {
        transactionQueue.add({
          data: toString(transaction),
          parent: parentTransaction,
        });
      });

    res.send({ process: true });
  });
}

module.exports = {
  get,
  update,
  process,
};
