const transactionsService = require('../services/transactions.service');
const { repairTransactionQueue } = require('../queues/repairTransactionQueue');
const { toString } = require('../utils/helpers');

async function get(req, res, next) {
  try {
    res.json(await transactionsService.get());
  } catch (err) {
    console.error(`Error while getting`, err.message);
    next(err);
  }
}

async function getSingle(req, res, next) {
  try {
    res.json(await transactionsService.getSingle());
  } catch (err) {
    console.error(`Error while getting`, err.message);
    next(err);
  }
}

async function getRepairs(req, res, next) {
  try {
    res.json(await transactionsService.getRepairs());
  } catch (err) {
    console.error(`Error while getting`, err.message);
    next(err);
  }
}

async function repairTransaction(req, res, next) {
  try {
    await transactionsService.repairTransaction(req.params.id, req.body);

    const transaction = await transactionsService.show(req.params.id);
    const parentTransaction = await transactionsService.show(
      transaction.parent_id
    );

    await repairTransactionQueue.add({
      data: transaction,
      parent: parentTransaction,
    });

    res.json({ process: true });
  } catch (err) {
    console.error(`Error while getting`, err.message);
    next(err);
  }
}

module.exports = {
  get,
  getSingle,
  getRepairs,
  repairTransaction,
};
