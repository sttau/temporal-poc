const customerService = require('../services/customers.service');
const { singleTransactionQueue } = require('../queues/singleTransactionQueue');
const { toString } = require('../utils/helpers');

async function get(req, res, next) {
  try {
    res.json(await customerService.get());
  } catch (err) {
    console.error(`Error while getting`, err.message);
    next(err);
  }
}

async function getTransactions(req, res, next) {
  try {
    res.json(await customerService.getTransactions(req.params.id));
  } catch (err) {
    console.error(`Error while getting`, err.message);
    next(err);
  }
}

async function processTransaction(req, res) {
  const transaction = await customerService.showTransaction(req.params.id);
  await customerService.updateProcessed(req.params.id);

  await singleTransactionQueue.add({
    data: toString(transaction),
  });

  res.send({ process: transaction });
}

async function customerTransaction(req, res, next) {
  try {
    res.json(await customerService.storeTransaction(req.body));
  } catch (err) {
    console.error(`Error while getting`, err.message);
    next(err);
  }
}

module.exports = {
  get,
  customerTransaction,
  getTransactions,
  processTransaction,
};
