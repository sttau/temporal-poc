const Queue = require('bull');

const transactionQueue = new Queue('transaction');

const { Connection, WorkflowClient } = require('@temporalio/client');
const { uuid4 } = require('@temporalio/workflow');
const { processTransaction } = require('../temporal/workflows');

transactionQueue.process(async function queueTransactions({ data, parent }) {
  const connection = await Connection.connect();

  const client = new WorkflowClient({
    connection,
  });

  const workflowId = 'transaction-' + uuid4();
  await client.start(processTransaction, {
    // type inference works! args: [name: string]
    args: [workflowId, data, parent],
    taskQueue: 'transactions',
    workflowId: workflowId,
  });
});

exports.transactionQueue = transactionQueue;
