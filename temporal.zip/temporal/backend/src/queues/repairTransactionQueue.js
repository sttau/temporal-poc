const Queue = require('bull');

const repairTransactionQueue = new Queue('repair_transaction');

const { Connection, WorkflowClient } = require('@temporalio/client');
const { repairTransaction } = require('../temporal/workflows');

repairTransactionQueue.process(async function queueRepairTransaction({ data }) {
  const connection = await Connection.connect();

  const client = new WorkflowClient({
    connection,
  });

  const workflowId = data.data.uuid;
  await client.start(repairTransaction, {
    // type inference works! args: [name: string]
    args: [workflowId, data.data.details, data.parent],
    taskQueue: 'transactions',
    workflowId: workflowId,
  });
});

exports.repairTransactionQueue = repairTransactionQueue;
