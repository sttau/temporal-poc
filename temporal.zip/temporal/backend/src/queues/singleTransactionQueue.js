const Queue = require('bull');

const singleTransactionQueue = new Queue('single_transaction');

const { Connection, WorkflowClient } = require('@temporalio/client');
const { uuid4 } = require('@temporalio/workflow');
const { processSingleTransaction } = require('../temporal/workflows');

singleTransactionQueue.process(async function queueSingleTransactions({
  data,
}) {
  const connection = await Connection.connect();

  const client = new WorkflowClient({
    connection,
  });

  const workflowId = 'single-transaction-' + uuid4();
  await client.start(processSingleTransaction, {
    // type inference works! args: [name: string]
    args: [workflowId, data],
    taskQueue: 'transactions',
    workflowId: workflowId,
  });
});

exports.singleTransactionQueue = singleTransactionQueue;
