const mongoose = require('mongoose');

const dataSchema = new mongoose.Schema({
  details: {
    required: false,
    type: Object,
  },
  status: {
    required: false,
    type: String,
  },
  uuid: {
    required: false,
    type: String,
  },
  message: {
    required: false,
    type: String,
  },
});

module.exports = mongoose.model('SingleTransactions', dataSchema);
