const mongoose = require('mongoose');

const dataSchema = new mongoose.Schema({
  details: {
    required: false,
    type: Object,
  },
  status: {
    required: false,
    type: String,
  },
  uuid: {
    required: false,
    type: String,
  },
  parent_id: {
    required: false,
    type: Object,
  },
  total: {
    required: false,
    type: Number,
  },
  processed: {
    required: false,
    type: Number,
  },
  failed: {
    required: false,
    type: Number,
  },
  repairing: {
    required: false,
    type: Number,
  },
  message: {
    required: false,
    type: String,
  },
  validation_err: {
    required: false,
    type: JSON,
  },
});

module.exports = mongoose.model('Transactions', dataSchema);
