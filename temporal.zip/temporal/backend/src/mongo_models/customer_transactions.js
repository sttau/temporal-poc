const mongoose = require('mongoose');

const dataSchema = new mongoose.Schema({
  customer_id: {
    required: true,
    type: String,
  },
  amount: {
    required: true,
    type: String,
  },
  processed: {
    type: Boolean,
  },
  date: {
    required: true,
    type: String,
  },
});

module.exports = mongoose.model('CustomerTransactions', dataSchema);
