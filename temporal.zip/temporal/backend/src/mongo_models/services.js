const mongoose = require('mongoose');

const dataSchema = new mongoose.Schema({
  name: {
    required: true,
    type: String,
  },
  status: {
    required: true,
    type: String,
  },
  performance: {
    required: true,
    type: String,
  },
  health: {
    required: true,
    type: String,
  },
});

module.exports = mongoose.model('Services', dataSchema);
