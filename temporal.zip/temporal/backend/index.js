const app = require('./app');

const start = async () => {
  const port = process.env.PORT || 3000;

  app.listen(port, () => {
    console.log(`Serve is up and running at the port ${port}`);
  });
};

start()
  .then(() => {
    console.log('Success start');
  })
  .catch((err) => {
    console.error('startUp Error: ', err);
  });
