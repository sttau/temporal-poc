'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    /**
     * Add seed commands here.
     *
     * Example:
     * await queryInterface.bulkInsert('People', [{
     *   name: 'John Doe',
     *   isBetaMember: false
     * }], {});
     */

    await queryInterface.bulkInsert(
      'Services',
      [
        {
          name: 'File Management',
          status: 'stopped',
          performance: 'normal',
          health: 'corrupt',
          createdAt: new Date(),
          updatedAt: new Date(),
        },
        {
          name: 'Database',
          status: 'stopped',
          performance: 'normal',
          health: 'corrupt',
          createdAt: new Date(),
          updatedAt: new Date(),
        },
        {
          name: 'FX Service',
          status: 'stopped',
          performance: 'normal',
          health: 'corrupt',
          createdAt: new Date(),
          updatedAt: new Date(),
        },
        {
          name: 'Entitlements',
          status: 'stopped',
          performance: 'normal',
          health: 'corrupt',
          createdAt: new Date(),
          updatedAt: new Date(),
        },
        {
          name: 'Payment Verification',
          status: 'stopped',
          performance: 'normal',
          health: 'corrupt',
          createdAt: new Date(),
          updatedAt: new Date(),
        },
        {
          name: 'Security scan',
          status: 'stopped',
          performance: 'normal',
          health: 'corrupt',
          createdAt: new Date(),
          updatedAt: new Date(),
        },
        {
          name: 'Payment Validation',
          status: 'stopped',
          performance: 'normal',
          health: 'corrupt',
          createdAt: new Date(),
          updatedAt: new Date(),
        },
        {
          name: 'Payment Object Store',
          status: 'stopped',
          performance: 'normal',
          health: 'corrupt',
          createdAt: new Date(),
          updatedAt: new Date(),
        },
      ],
      {}
    );
  },

  async down(queryInterface, Sequelize) {
    /**
     * Add commands to revert seed here.
     *
     * Example:
     * await queryInterface.bulkDelete('People', null, {});
     */
  },
};
