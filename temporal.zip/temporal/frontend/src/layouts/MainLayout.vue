<script setup>
import { ref } from "vue";
import { useAuthStore } from "@/stores/auth";
import { useRouter } from "vue-router";
const drawer = ref(true);
const authStore = useAuthStore();
const router = useRouter();
function logout() {
  router.push({ name: "home" });
}
</script>
<template>
  <q-layout view="lHh Lpr lff" class="shadow-2 rounded-borders full-height">
    <q-header elevated class="bg-primary">
      <q-toolbar>
        <q-toolbar-title>Temporal</q-toolbar-title>
        <q-btn flat @click="drawer = !drawer" round dense icon="menu" />
      </q-toolbar>
    </q-header>

    <q-drawer v-model="drawer" show-if-above :width="300" :breakpoint="500">
      <q-scroll-area
        style="height: calc(100% - 150px); border-right: 1px solid #ddd"
      >
        <q-list padding>
          <q-item :to="{ name: 'dashboard' }" v-ripple>
            <q-item-section avatar>
              <q-icon name="home" color="blue" />
            </q-item-section>

            <q-item-section> Home </q-item-section>
          </q-item>

          <q-separator spaced />

          <q-item-label header>Management</q-item-label>

          <q-item :to="{ name: 'transactions' }" v-ripple>
            <q-item-section avatar>
              <q-icon name="receipt_long" color="green" />
            </q-item-section>

            <q-item-section> Transactions </q-item-section>
          </q-item>

          <q-item :to="{ name: 'transactions-repair' }" v-ripple>
            <q-item-section avatar>
              <q-icon name="receipt_long" color="green" />
            </q-item-section>

            <q-item-section> Repair Transactions </q-item-section>
          </q-item>

          <q-item :to="{ name: 'single-transactions' }" v-ripple>
            <q-item-section avatar>
              <q-icon name="receipt_long" color="green" />
            </q-item-section>

            <q-item-section> Single Transactions </q-item-section>
          </q-item>

          <q-item :to="{ name: 'transaction-create' }" v-ripple>
            <q-item-section avatar>
              <q-icon name="receipt_long" color="yellow" />
            </q-item-section>

            <q-item-section> Create Transaction </q-item-section>
          </q-item>

          <q-item :to="{ name: 'services' }" v-ripple>
            <q-item-section avatar>
              <q-icon name="settings" color="red" />
            </q-item-section>

            <q-item-section> Services </q-item-section>
          </q-item>

          <q-item :to="{ name: 'customers' }" v-ripple>
            <q-item-section avatar>
              <q-icon name="person" color="blue" />
            </q-item-section>

            <q-item-section> Customers </q-item-section>
          </q-item>

          <q-item :to="{ name: 'customers-transactions' }" v-ripple>
            <q-item-section avatar>
              <q-icon name="receipt_long" color="blue" />
            </q-item-section>

            <q-item-section> Customer Transactions </q-item-section>
          </q-item>

          <q-item clickable v-ripple @click="logout">
            <q-item-section avatar>
              <q-icon name="logout" color="pink" />
            </q-item-section>

            <q-item-section> Log out </q-item-section>
          </q-item>
        </q-list>
      </q-scroll-area>
    </q-drawer>

    <q-page-container>
      <q-page padding>
        <slot />
      </q-page>
    </q-page-container>
  </q-layout>
</template>
