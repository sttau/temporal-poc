<template>
  <q-layout view="hHh lpR fFf" class="row justify-center content-center">
    <slot />
  </q-layout>
</template>
