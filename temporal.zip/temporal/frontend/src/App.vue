<script setup>
import { RouterView, useRoute } from "vue-router";
import { computed } from "vue";
const route = useRoute();
const layout = computed(() => {
  if (!route.meta.layout) return "default-layout";
  return `${route.meta.layout}-layout`;
});
</script>

<template>
  <component :is="layout">
    <RouterView />
  </component>
</template>
