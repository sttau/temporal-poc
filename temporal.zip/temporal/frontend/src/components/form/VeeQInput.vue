<script setup>
import { useField } from "vee-validate";
import { watch, toRef } from "vue";
const props = defineProps({
  type: {
    type: String,
    default: "text",
  },
  modelValue: {
    type: [String, Number],
  },
  value: {
    type: [String, Number],
  },
  name: {
    type: String,
    required: true,
  },
  rules: {
    type: [Object, String],
  },
  label: {
    type: String,
  },
  prependIcon: {
    type: String,
  },
  disable: {
    type: Boolean,
    default: false,
  },
});
const rules = toRef(props, "rules");
const emits = defineEmits(["update:modelValue"]);

const {
  value: inputValue,
  errorMessage,
  handleBlur,
  handleChange,
} = useField(props.name, rules, {
  initialValue: props.modelValue,
  label: props.label || props.name,
});
watch(inputValue, (newVal) => {
  emits("update:modelValue", newVal);
});
</script>

<template>
  <q-input
    v-model="inputValue"
    :error-message="errorMessage"
    :error="!!errorMessage"
    @input="handleChange"
    @blur="handleBlur"
    :model-value="inputValue"
    :label="label"
    :type="type"
    :disable="disable"
  >
    <template v-slot:prepend v-if="prependIcon">
      <q-icon :name="prependIcon" />
    </template>
  </q-input>
</template>
