<script setup>
import { useServiceStore } from "@/stores/service";
import { onMounted } from "vue";

const serviceStore = useServiceStore();

onMounted(() => {
  serviceStore.get();
});

const columns = [
  {
    name: "name",
    label: "Name",
    field: "name",
    align: "left",
    sortable: false,
  },
  {
    name: "status",
    field: "status",
    label: "Status",
    align: "left",
    sortable: false,
  },
  {
    name: "health",
    field: "health",
    label: "Health",
    align: "left",
    sortable: false,
  },
  {
    name: "performance",
    field: "performance",
    label: "Performance",
    align: "left",
    sortable: false,
  },
  {
    name: "actions",
    field: "actions",
    label: "Actions",
    align: "right",
    sortable: false,
  },
];

async function changeStatus(id, payload) {
  await serviceStore.update(id, {
    status: payload === "stopped" ? "running" : "stopped",
  });
  await serviceStore.get();
}

async function changePerformance(id, payload) {
  await serviceStore.update(id, {
    performance: payload === "normal" ? "slow down" : "normal",
  });
  await serviceStore.get();
}

async function changeHealth(id, payload) {
  await serviceStore.update(id, {
    health: payload === "healthy" ? "corrupt" : "healthy",
  });
  await serviceStore.get();
}
</script>

<template>
  <div class="q-pa-sm">
    <q-table
      title="Services"
      :rows="serviceStore.services"
      :columns="columns"
      row-key="name"
      :rows-per-page-options="[0]"
    >
      <template v-slot:body-cell-status="props">
        <q-td :props="props">
          <div>
            <q-badge
              class="text-uppercase"
              :color="props.value === 'running' ? 'green' : 'red'"
              :label="props.value"
            />
          </div>
        </q-td>
      </template>

      <template v-slot:body-cell-performance="props">
        <q-td :props="props">
          <div>
            <q-badge
              class="text-uppercase"
              :color="props.value === 'normal' ? 'green' : 'orange'"
              :label="props.value"
            />
          </div>
        </q-td>
      </template>

      <template v-slot:body-cell-health="props">
        <q-td :props="props">
          <div>
            <q-badge
              class="text-uppercase"
              :color="props.value === 'healthy' ? 'green' : 'red'"
              :label="props.value"
            />
          </div>
        </q-td>
      </template>

      <template v-slot:body-cell-actions="props">
        <q-td :props="props">
          <div>
            <q-btn
              size="sm"
              icon="refresh"
              outline
              @click="changeStatus(props.row._id, props.row.status)"
            >
              {{ props.row.status === "stopped" ? "Start" : "Stop" }} Service
            </q-btn>
            <q-btn
              @click="changePerformance(props.row._id, props.row.performance)"
              size="sm"
              icon="monitor_heart"
              outline
              class="q-ml-sm"
            >
              {{ props.row.performance === "normal" ? "Slow down" : "Normal" }}
            </q-btn>
            <q-btn
              @click="changeHealth(props.row._id, props.row.health)"
              size="sm"
              icon="health_and_safety"
              outline
              class="q-ml-sm"
            >
              {{ props.row.health === "corrupt" ? "Heal" : "Corrupt" }}
            </q-btn>
          </div>
        </q-td>
      </template>
    </q-table>
  </div>
</template>
