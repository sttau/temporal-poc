<script setup>
import { onMounted, ref, watch } from "vue";
import { useCustomerStore } from "@/stores/customers";
import { Notify } from "quasar";

const customerStore = useCustomerStore();
const customer = ref();

onMounted(() => {
  customerStore.get();
});

watch(customer, (newVal) => {
  customerStore.getTransactions(newVal._id);
});

const columns = [
  {
    name: "amount",
    label: "Amount",
    field: "amount",
    align: "left",
    sortable: false,
  },
  {
    name: "date",
    label: "Date",
    field: "date",
    align: "left",
    sortable: false,
  },
  {
    name: "actions",
    label: "Actions",
    field: "actions",
    align: "right",
    sortable: false,
  },
];

async function confirm(data) {
  try {
    await customerStore.processTransaction(data._id);
    await customerStore.getTransactions(customer.value._id);
    Notify.create({
      message: "Successfully started processing transaction",
      color: "green",
      position: "bottom-right",
      icon: "check_circle",
    });
  } catch {
    Notify.create({
      message: "Error while processing transaction",
      color: "red",
      position: "top-right",
      icon: "warning",
    });
  }
}
</script>

<template>
  <div class="q-pa-sm">
    <q-card class="q-mb-lg">
      <q-card-section>
        <q-select
          v-model:model-value="customer"
          :options="customerStore.customers"
          option-value="_id"
          option-label="name"
          label="Customer"
        />
      </q-card-section>
    </q-card>
    <q-table
      title="Transactions"
      :rows="customerStore.transactions"
      :columns="columns"
      row-key="name"
      :rows-per-page-options="[0]"
    >
      <template v-slot:body-cell-actions="props">
        <q-td :props="props">
          <div>
            <q-btn size="sm" @click="confirm(props.row)" color="green">
              CONFIRM
            </q-btn>
          </div>
        </q-td>
      </template>
    </q-table>
  </div>
</template>
