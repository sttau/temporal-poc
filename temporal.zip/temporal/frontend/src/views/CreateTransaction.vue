<script setup>
import VeeQSelect from "@/components/form/VeeQSelect.vue";
import { useForm } from "vee-validate";
import { useCustomerStore } from "@/stores/customers";
import { onMounted } from "vue";
import VeeQInput from "@/components/form/VeeQInput.vue";
import VeeQDate from "@/components/form/VeeQDate.vue";
import { Notify } from "quasar";
const { handleSubmit, resetForm } = useForm();

const customerStore = useCustomerStore();
onMounted(() => {
  customerStore.get();
});

const onSubmit = handleSubmit((values) => {
  try {
    customerStore.storeTransaction({
      customer_id: values.customer._id,
      amount: values.amount,
      date: values.date,
    });

    Notify.create({
      message: "Successfully created transaction",
      color: "green",
      position: "bottom-right",
      icon: "check_circle",
    });
    resetForm();
  } catch {
    Notify.create({
      message: "Error while creating transaction",
      color: "red",
      position: "top-right",
      icon: "warning",
    });
  }
});
</script>
<template>
  <div class="q-pa-sm">
    <q-card>
      <q-card-section>
        <div class="text-h6">Create Transaction</div>
      </q-card-section>

      <q-separator />

      <q-card-section>
        <form @submit="onSubmit">
          <vee-q-select
            :options="customerStore.customers"
            option-label="name"
            option-value="id"
            label="Customer"
            name="customer"
            rules="required"
          />

          <vee-q-input
            label="Amount"
            name="amount"
            type="number"
            step="0.01"
            rules="required"
          />

          <vee-q-date label="Date" name="date" rules="required" />

          <div class="row justify-end">
            <q-btn color="primary" type="submit">CREATE</q-btn>
          </div>
        </form>
      </q-card-section>
    </q-card>
  </div>
</template>
