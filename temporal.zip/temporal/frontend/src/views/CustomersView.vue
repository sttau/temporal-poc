<script setup>
import { onMounted } from "vue";
import { useCustomerStore } from "@/stores/customers";

const customerStore = useCustomerStore();

onMounted(() => {
  customerStore.get();
});

const columns = [
  {
    name: "name",
    label: "Name",
    field: "name",
    align: "left",
    sortable: false,
  },
];
</script>

<template>
  <div class="q-pa-sm">
    <q-table
      title="Customers"
      :rows="customerStore.customers"
      :columns="columns"
      row-key="name"
      :rows-per-page-options="[0]"
    >
    </q-table>
  </div>
</template>
