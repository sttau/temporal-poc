<script setup>
import VeeQInput from "@/components/form/VeeQInput.vue";
import { ref } from "vue";
import { useAuthStore } from "@/stores/auth";
import { useRouter } from "vue-router";
import { Form } from "vee-validate";
const authStore = useAuthStore();
const router = useRouter();
const loading = ref(false);
function handleSubmit(values, { setFieldError }) {
  router.push({ name: "dashboard" });
}
</script>

<template>
  <q-card style="width: 600px">
    <q-card-section class="bg-primary text-white">
      <div class="text-h6">Login</div>
    </q-card-section>

    <Form @submit="handleSubmit">
      <q-card-section>
        <vee-q-input label="Email" name="email" rules="required|email" />
        <vee-q-input
          label="Password"
          type="password"
          name="password"
          rules="required"
        />
      </q-card-section>

      <q-card-actions class="justify-end">
        <q-btn
          color="primary"
          outline
          class="q-mr-sm"
          padding="5px 20px"
          type="submit"
          :loading="loading"
        >
          Login
        </q-btn>
      </q-card-actions>
    </Form>
  </q-card>
</template>

<style scoped lang="scss"></style>
