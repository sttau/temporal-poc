<script setup>
import { useTransactionStore } from "@/stores/transaction";
import { computed, onMounted, ref } from "vue";

const transactionStore = useTransactionStore();

onMounted(() => {
  transactionStore.getSingle();
});

const columns = [
  {
    name: "id",
    label: "#ID",
    field: "_id",
    align: "left",
    sortable: false,
  },
  {
    name: "customer",
    field: "customer",
    label: "Customer",
    align: "left",
    sortable: false,
  },
  {
    name: "amount",
    field: "amount",
    label: "Amount",
    align: "left",
    sortable: false,
  },
  {
    name: "date",
    field: "date",
    label: "Date",
    align: "left",
    sortable: false,
  },
  {
    name: "status",
    field: "status",
    label: "Status",
    align: "right",
    sortable: false,
  },
];
</script>

<template>
  <div class="q-pa-sm">
    <q-table
      title="Transactions"
      :rows="transactionStore.single_transactions"
      :columns="columns"
      row-key="name"
      :rows-per-page-options="[0]"
    >
      <template v-slot:body-cell-customer="props">
        <q-td :props="props">
          <div>
            {{ props.row.details.customer.name }}
          </div>
        </q-td>
      </template>

      <template v-slot:body-cell-amount="props">
        <q-td :props="props">
          <div>
            {{ props.row.details.transaction.amount }}
          </div>
        </q-td>
      </template>

      <template v-slot:body-cell-date="props">
        <q-td :props="props">
          <div>
            {{ props.row.details.transaction.date }}
          </div>
        </q-td>
      </template>

      <template v-slot:body-cell-status="props">
        <q-td :props="props">
          <div>
            <q-badge
              class="text-uppercase"
              :color="
                props.value === 'completed'
                  ? 'green'
                  : props.value === 'pending'
                  ? 'orange'
                  : 'red'
              "
              :label="props.value"
            />
          </div>
        </q-td>
      </template>
    </q-table>
  </div>
</template>
