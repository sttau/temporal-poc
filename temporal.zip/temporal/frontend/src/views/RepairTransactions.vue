<script setup>
import { nextTick, onMounted, ref } from "vue";
import { useTransactionStore } from "@/stores/transaction";
import VeeQInput from "@/components/form/VeeQInput.vue";
import { useForm } from "vee-validate";

const transactionStore = useTransactionStore();
const modal = ref(false);
const repairModal = ref(false);
const details = ref({});
const repairData = ref({});
const { setFieldError, resetForm, handleSubmit } = useForm();

function showDetails(data) {
  details.value = data;
  modal.value = true;
}

function repair(data) {
  repairData.value = data;
  repairModal.value = true;

  resetForm({
    values: data.details,
  });
  if (data.validation_err) {
    nextTick(() => {
      repairData.value.validation_err.forEach((i) => {
        setFieldError(i.context.key, i.message);
      });
    });
  }
}

function existInErrors(column) {
  if (repairData.value.validation_err) {
    return (
      repairData.value.validation_err.findIndex((i) => {
        return i.context.key === column;
      }) > -1
    );
  }

  return false;
}

onMounted(() => {
  transactionStore.getRepairs();
});

const columnsValidation = ref([
  "Order Party Account",
  "Order Party Currency",
  "Charges Account",
  "Charges Account Currency",
  "Account Currency",
  "Transaction Amount",
  "Scheduled date",
  "Transaction currency",
  "Counter Party Account",
  "Counter Account Type",
  "Counter Bank Name",
  "Counter Account Currency",
  "Product code",
  "Value date / Execution date",
  "Transaction Mode",
]);

const columns = [
  {
    name: "parent_id",
    label: "Parent ID",
    field: "parent_id",
    align: "left",
    sortable: false,
  },
  {
    name: "status",
    label: "Status",
    field: "status",
    align: "left",
    sortable: false,
  },
  {
    name: "actions",
    label: "Actions",
    field: "actions",
    align: "right",
    sortable: false,
  },
];

const onSubmit = handleSubmit(async (values) => {
  await transactionStore.repairTransaction(repairData.value._id, values);
  transactionStore.getRepairs();
});
</script>

<template>
  <div class="q-pa-sm">
    <q-table
      title="Repair Transactions"
      :rows="transactionStore.repair_transactions"
      :columns="columns"
      row-key="name"
      :rows-per-page-options="[0]"
    >
      <template v-slot:body-cell-status="props">
        <q-td :props="props">
          <div>
            <q-badge
              class="text-uppercase"
              :color="
                props.value === 'completed'
                  ? 'green'
                  : props.value === 'pending'
                  ? 'orange'
                  : props.value === 'waiting repair'
                  ? 'primary'
                  : 'red'
              "
              :label="props.value"
            />
          </div>
        </q-td>
      </template>

      <template v-slot:body-cell-actions="props">
        <q-td :props="props">
          <div>
            <q-btn
              size="sm"
              color="green"
              @click="showDetails(props.row)"
              class="q-mr-lg"
            >
              View Details
            </q-btn>
            <q-btn size="sm" @click="repair(props.row)" color="green">
              Repair
            </q-btn>
          </div>
        </q-td>
      </template>
    </q-table>

    <q-dialog v-model="repairModal">
      <q-card style="width: 700px; max-width: 80vw">
        <q-card-section>
          <div class="text-h6">Repair Transaction</div>
        </q-card-section>

        <q-card-section class="q-pt-none">
          <form @submit="onSubmit">
            <template v-for="(column, key) in columnsValidation" :key="key">
              <vee-q-input
                :label="column"
                :name="column"
                v-if="existInErrors(column)"
              />
            </template>
          </form>
        </q-card-section>

        <q-card-actions align="right" class="bg-white text-teal">
          <q-btn flat label="Repair" v-close-popup @click="onSubmit" />
        </q-card-actions>
      </q-card>
    </q-dialog>
    <q-dialog v-model="modal">
      <q-card style="width: 700px; max-width: 80vw">
        <q-card-section>
          <div class="text-h6">Details #{{ details.uuid }}</div>
          <q-badge
            class="text-uppercase"
            :color="
              details.status === 'completed'
                ? 'green'
                : details.status === 'pending'
                ? 'orange'
                : details.status === 'waiting repair'
                ? 'primary'
                : 'red'
            "
            :label="details.status"
          />
        </q-card-section>

        <q-card-section class="q-pt-none">
          <div>
            <q-list bordered separator>
              <q-item
                v-for="(item, key) in Object.keys(details.details)"
                :key="key"
              >
                <q-item-section>{{ item }}</q-item-section>
                <q-item-section>{{ details.details[item] }}</q-item-section>
              </q-item>
              <q-item v-if="details.status === 'failed'">
                <q-item-section>Reason</q-item-section>
                <q-item-section class="text-red">{{
                  details.message
                }}</q-item-section>
              </q-item>
            </q-list>
          </div>
        </q-card-section>

        <q-card-actions align="right" class="bg-white text-teal">
          <q-btn flat label="OK" v-close-popup />
        </q-card-actions>
      </q-card>
    </q-dialog>
  </div>
</template>
