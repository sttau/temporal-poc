<script setup>
import { useTransactionStore } from "@/stores/transaction";
import { computed, onMounted, ref } from "vue";

const transactionStore = useTransactionStore();

onMounted(() => {
  transactionStore.get();
});

const modal = ref(false);
const details = ref({});

function showDetails(data) {
  details.value = data;
  modal.value = true;
}
const columns = [
  {
    name: "id",
    label: "#ID",
    field: "id",
    align: "left",
    sortable: false,
  },
  {
    name: "name",
    field: "name",
    label: "File",
    align: "left",
    sortable: false,
  },
  {
    name: "total",
    field: "total",
    label: "Total",
    align: "left",
    sortable: false,
  },
  {
    name: "processed",
    field: "processed",
    label: "Processed",
    align: "left",
    sortable: false,
  },
  {
    name: "failed",
    field: "failed",
    label: "Failed",
    align: "left",
    sortable: false,
  },
  {
    name: "repairing",
    field: "repairing",
    label: "Waiting repair",
    align: "left",
    sortable: false,
  },
  {
    name: "status",
    field: "status",
    label: "Status",
    align: "left",
    sortable: false,
  },
  {
    name: "actions",
    field: "actions",
    label: "Actions",
    align: "right",
    sortable: false,
  },
];

const columnsChild = [
  {
    name: "id",
    label: "#ID",
    field: "uuid",
    align: "left",
    sortable: false,
  },
  {
    name: "status",
    field: "status",
    label: "Status",
    align: "left",
    sortable: false,
  },
  {
    name: "actions",
    field: "actions",
    label: "Actions",
    align: "right",
    sortable: false,
  },
];

const parentTransactions = computed(() => {
  return transactionStore.transactions.filter((i) => {
    return !i.parent_id;
  });
});

function getChildTransactions(id) {
  return transactionStore.transactions.filter((i) => {
    return i.parent_id === id;
  });
}
</script>

<template>
  <div class="q-pa-sm">
    <q-table
      title="Transactions"
      :rows="parentTransactions"
      :columns="columns"
      row-key="name"
      :rows-per-page-options="[0]"
    >
      <template v-slot:body="props">
        <q-tr :props="props">
          <q-td :props="props" key="id">
            {{ props.row._id }}
          </q-td>
          <q-td :props="props" key="name">
            {{ props.row.details.name }}
          </q-td>
          <q-td :props="props" key="total">
            {{ props.row.total }}
          </q-td>
          <q-td :props="props" key="processed">
            {{ props.row.processed }}
          </q-td>
          <q-td :props="props" key="failed">
            {{ props.row.failed }}
          </q-td>
          <q-td :props="props" key="repairing">
            {{ props.row.repairing || 0 }}
          </q-td>
          <q-td :props="props" key="status">
            <q-badge
              class="text-uppercase"
              :color="
                +(props.row.repairing || 0) > 0 || props.row.processed === 0
                  ? 'orange'
                  : 'green'
              "
              :label="
                +(props.row.repairing || 0) > 0 || props.row.processed === 0
                  ? 'pending'
                  : 'completed'
              "
            />
          </q-td>
          <q-td key="actions" :props="props">
            <q-btn
              size="md"
              :color="props.row.expand ? 'blue' : 'green'"
              @click="props.row.expand = !props.row.expand"
              >{{ !props.row.expand ? "Show" : "Hide" }} Transactions</q-btn
            >
          </q-td>
        </q-tr>

        <q-tr v-show="props.row.expand" :props="props" class="myclass">
          <q-td colspan="100%">
            <q-table
              :rows="getChildTransactions(props.row._id)"
              :columns="columnsChild"
            >
              <template v-slot:body-cell-status="props">
                <q-td :props="props">
                  <div>
                    <q-badge
                      class="text-uppercase"
                      :color="
                        props.value === 'completed'
                          ? 'green'
                          : props.value === 'pending'
                          ? 'orange'
                          : props.value === 'waiting repair'
                          ? 'primary'
                          : 'red'
                      "
                      :label="props.value"
                    />
                  </div>
                </q-td>
              </template>

              <template v-slot:body-cell-actions="props">
                <q-td :props="props">
                  <div>
                    <q-btn
                      size="sm"
                      color="green"
                      @click="showDetails(props.row)"
                    >
                      View Details
                    </q-btn>
                  </div>
                </q-td>
              </template>
            </q-table>
          </q-td>
        </q-tr>
      </template>
    </q-table>

    <q-dialog v-model="modal">
      <q-card style="width: 700px; max-width: 80vw">
        <q-card-section>
          <div class="text-h6">Details #{{ details.uuid }}</div>
          <q-badge
            class="text-uppercase"
            :color="
              details.status === 'completed'
                ? 'green'
                : details.status === 'pending'
                ? 'orange'
                : details.status === 'waiting repair'
                ? 'primary'
                : 'red'
            "
            :label="details.status"
          />
        </q-card-section>

        <q-card-section class="q-pt-none">
          <div>
            <q-list bordered separator>
              <q-item
                v-for="(item, key) in Object.keys(details.details)"
                :key="key"
              >
                <q-item-section>{{ item }}</q-item-section>
                <q-item-section>{{ details.details[item] }}</q-item-section>
              </q-item>
              <q-item v-if="details.status === 'failed'">
                <q-item-section>Reason</q-item-section>
                <q-item-section class="text-red">{{
                  details.message
                }}</q-item-section>
              </q-item>
            </q-list>
          </div>
        </q-card-section>

        <q-card-actions align="right" class="bg-white text-teal">
          <q-btn flat label="OK" v-close-popup />
        </q-card-actions>
      </q-card>
    </q-dialog>
  </div>
</template>
