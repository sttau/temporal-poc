<script setup>
import { ref } from "vue";
import { useServiceStore } from "@/stores/service";
import { Notify } from "quasar";

const serviceStore = useServiceStore();
const file = ref(null);
const error = ref(null);
const loading = ref(false);

async function handleProcess() {
  if (!file.value) {
    error.value = "File is required";
    Notify.create({
      message: "Please choose excel file.",
      color: "red",
      position: "top-right",
      icon: "warning",
    });

    return;
  }

  loading.value = true;
  try {
    await serviceStore.processTransactions(file.value);
    file.value = null;
    error.value = null;

    Notify.create({
      message:
        "Started processing transactions you can check in transactions tab.",
      color: "green",
      position: "bottom-right",
      icon: "check_circle",
    });
  } catch (res) {
    error.value = res.response.data.error.message;
    Notify.create({
      message: "Invalid attached file",
      color: "red",
      position: "bottom-right",
      icon: "warning",
    });
  } finally {
    loading.value = false;
  }
}
</script>

<template>
  <div class="q-pa-md">
    <p>Upload Excel file to process transactions</p>
    <q-file
      label="Pick excel file"
      filled
      style="max-width: 500px"
      v-model="file"
      :error="!!error"
      :error-message="error"
    />
    <q-btn
      color="green"
      class="q-mt-sm"
      @click="handleProcess"
      :loading="loading"
      >Process</q-btn
    >
  </div>
</template>
