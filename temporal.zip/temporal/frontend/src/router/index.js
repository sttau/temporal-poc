import { createRouter, createWebHistory } from "vue-router";
import LoginView from "../views/LoginView.vue";

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: "/",
      name: "home",
      component: LoginView,
      meta: { layout: "auth" },
    },
    {
      path: "/dashboard",
      name: "dashboard",
      component: () => import("@/views/DashboardView.vue"),
      meta: { layout: "main" },
    },
    {
      path: "/services",
      name: "services",
      component: () => import("@/views/ServicesView.vue"),
      meta: { layout: "main" },
    },
    {
      path: "/customers",
      name: "customers",
      component: () => import("@/views/CustomersView.vue"),
      meta: { layout: "main" },
    },
    {
      path: "/customers/transactions",
      name: "customers-transactions",
      component: () => import("@/views/CustomerTransactions.vue"),
      meta: { layout: "main" },
    },
    {
      path: "/transactions",
      name: "transactions",
      component: () => import("@/views/TransactionsView.vue"),
      meta: { layout: "main" },
    },
    {
      path: "/transactions/repair",
      name: "transactions-repair",
      component: () => import("@/views/RepairTransactions.vue"),
      meta: { layout: "main" },
    },
    {
      path: "/single-transactions",
      name: "single-transactions",
      component: () => import("@/views/SingleTransactionsView.vue"),
      meta: { layout: "main" },
    },
    {
      path: "/transactions/create",
      name: "transaction-create",
      component: () => import("@/views/CreateTransaction.vue"),
      meta: { layout: "main" },
    },
  ],
});

export default router;
