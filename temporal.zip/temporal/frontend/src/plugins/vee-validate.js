import { defineRule } from "vee-validate";
import {
  required,
  email,
  min,
  max,
  min_value,
  max_value,
  regex,
} from "@vee-validate/rules";

defineRule("required", required);
defineRule("email", email);
defineRule("min", min);
defineRule("max", max);
defineRule("regex", regex);
defineRule("min_value", min_value);
defineRule("max_value", max_value);
