import serviceRepository from "@/api/repositories/serviceRepository";
import transactionRepository from "@/api/repositories/transactionRepository";
import customerRepository from "@/api/repositories/customerRepository";

const repositories = {
  service: serviceRepository,
  transaction: transactionRepository,
  customer: customerRepository,
};

export const RepositoryFactory = {
  get: (name) => {
    let splitName = name.split("/");

    let returnObj = null;

    splitName.forEach((i) => {
      returnObj = !returnObj ? repositories[i] : returnObj[i];
    });

    return returnObj;
  },
};
