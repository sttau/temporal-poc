import Repository from "@/api/Repository";

const resources = "customers";

export default {
  get() {
    return Repository.get(`${resources}`);
  },
  getTransactions(id) {
    return Repository.get(`${resources}/transactions/${id}`);
  },
  storeTransaction(payload) {
    return Repository.post(`${resources}/store/transaction`, payload);
  },
  processTransaction(id) {
    return Repository.get(`${resources}/transactions/process/${id}`);
  },
};
