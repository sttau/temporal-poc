import Repository from "@/api/Repository";

const resources = "services";

export default {
  get() {
    return Repository.get(`${resources}`);
  },
  update(id, payload) {
    return Repository.post(`${resources}/${id}`, payload);
  },
  processTransactions(files) {
    const formData = new FormData();
    formData.append("file", files);

    return Repository.post(`${resources}/process`, formData, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    });
  },
};
