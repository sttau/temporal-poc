import Repository from "@/api/Repository";

const resources = "transactions";

export default {
  get() {
    return Repository.get(`${resources}`);
  },
  getSingle() {
    return Repository.get(`${resources}/single`);
  },
  getRepairs() {
    return Repository.get(`${resources}/repairs`);
  },
  repairTransaction(id, payload) {
    return Repository.post(`${resources}/repair/${id}`, payload);
  },
};
