import { defineStore } from "pinia";
import { RepositoryFactory } from "@/api/RepositoryFactory";

export const useCustomerStore = defineStore({
  id: "customer",
  state: () => ({
    s_customers: [],
    s_transactions: [],
  }),
  getters: {
    customers: (state) => state.s_customers,
    transactions: (state) => state.s_transactions,
  },
  actions: {
    async get() {
      const data = await RepositoryFactory.get("customer").get();

      this.s_customers = data.data;
    },

    async getTransactions(id) {
      const data = await RepositoryFactory.get("customer").getTransactions(id);

      this.s_transactions = data.data;
    },

    async storeTransaction(payload) {
      await RepositoryFactory.get("customer").storeTransaction(payload);
    },

    async processTransaction(id) {
      await RepositoryFactory.get("customer").processTransaction(id);
    },
  },
});
