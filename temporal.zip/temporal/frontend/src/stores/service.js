import { defineStore } from "pinia";
import { RepositoryFactory } from "@/api/RepositoryFactory";

export const useServiceStore = defineStore({
  id: "service",
  state: () => ({
    s_services: [],
  }),
  getters: {
    services: (state) => state.s_services,
  },
  actions: {
    async get() {
      const data = await RepositoryFactory.get("service").get();

      this.s_services = data.data;
    },
    async update(id, payload) {
      await RepositoryFactory.get("service").update(id, payload);
    },
    async processTransactions(files) {
      return await RepositoryFactory.get("service").processTransactions(files);
    },
    logout() {
      return new Promise((resolve) => {
        this.token = null;
        this.auth_user = "{}";
        resolve();
      });
    },
  },
});
