import { defineStore } from "pinia";
import { RepositoryFactory } from "@/api/RepositoryFactory";

export const useTransactionStore = defineStore({
  id: "transaction",
  state: () => ({
    s_transactions: [],
    s_single_transactions: [],
    s_repair_transactions: [],
  }),
  getters: {
    transactions: (state) => state.s_transactions,
    single_transactions: (state) => state.s_single_transactions,
    repair_transactions: (state) => state.s_repair_transactions,
  },
  actions: {
    async get() {
      const data = await RepositoryFactory.get("transaction").get();

      this.s_transactions = data.data;
    },
    async getSingle() {
      const data = await RepositoryFactory.get("transaction").getSingle();

      this.s_single_transactions = data.data;
    },
    async getRepairs() {
      const data = await RepositoryFactory.get("transaction").getRepairs();

      this.s_repair_transactions = data.data;
    },
    async repairTransaction(id, payload) {
      return await RepositoryFactory.get("transaction").repairTransaction(
        id,
        payload
      );
    },
  },
});
