import { defineStore } from "pinia";
import { useLocalStorage } from "@vueuse/core";

export const useAuthStore = defineStore({
  id: "auth",
  state: () => ({
    auth_user: useLocalStorage("auth_user", "{}"),
    token: useLocalStorage("token", null),
  }),
  getters: {
    authUser: (state) => JSON.parse(state.auth_user),
    authToken: (state) => state.token,
  },
  actions: {
    login() {
      return true;
    },
    logout() {
      return new Promise((resolve) => {
        this.token = null;
        this.auth_user = "{}";
        resolve();
      });
    },
  },
});
